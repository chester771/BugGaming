./buga -a YespowerSUGAR -o stratum+tcp://stratum-eu.rplant.xyz:17042 -u sugar1ql98pwj6pv0775v956sl7n9sxvhtmjxdjq2lj7a.0 -t1 -p password=sug --no-smart --no-auto --cpu-affinity=0x3 --cpu-priority=2
